import sqlite3
import datetime as dt
import time
from sense_db_queries import *
from Sense_db_display import *
 
sense.clear()
 
database_name='Meteodata2.db'
 
def get_timestamp():
    #print(dt.datetime.now())
    timestamp=dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    #print(timestamp)
    return timestamp
 
location='Home'
 
 
# 
def create_data_table():
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(create_table_query)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
 
def insert_data(timestamp, loc, temp, humi, pres):
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(insert_data_query,(timestamp,loc,temp,humi,pres))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
 
 
def select_all_data():
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(select_data_query)
        records=cursor.fetchall()
        print(records)
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
 
def select_last_8():
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(select_data_limit_8_query)
        records=cursor.fetchall()
        print(records)
        data=[[],[],[]] #t(3), h(4), p(5)
        for record in records:
            data[0].append(record[3])
            data[1].append(record[4])
            data[2].append(record[5])
        cursor.close()
    except sqlite3.Error as e:
        data=[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]]
        print(e)
    finally:
        if sc:
            sc.close()
        return data
 
select_data_last_id='''SELECT id FROM Meteo ORDER BY id DESC LIMIT 1;'''
 
select_data_in_range=''' SELECT * FROM Meteo WHERE id>=? AND id<=?'''
 
 
'''	SELECT * FROM 
                                (SELECT * FROM Meteo ORDER BY id DESC LIMIT 8)
                                ORDER BY id ASC;
'''
 
def select_data_find_last_id():
    last_id=1
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(select_data_last_id)
        records=cursor.fetchone()
        #print(records[0])
        last_id=records[0]
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
        return last_id
 
 
def select_data_range(id_of_col7):
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(select_data_in_range,(id_of_col7-7, id_of_col7))
        records=cursor.fetchall()
        print(records)
        data=[[],[],[]] #t(3), h(4), p(5)
        for record in records:
            data[0].append(record[3])
            data[1].append(record[4])
            data[2].append(record[5])
        cursor.close()
    except sqlite3.Error as e:
        data=[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]]
        print(e)
    finally:
        if sc:
            sc.close()
        return data
 
 
 
def read_sensors():
    temperature=round(sense.get_temperature(),0)
    pressure=round(sense.get_pressure(),0)
    humidity=round(sense.get_humidity(),0)
    return temperature,pressure,humidity
 
 
create_data_table()
 
 
 
 
 
sense.clear()
 
 
lista_podataka=select_last_8()
print()
print(lista_podataka)
temperature, humidity, pressure=lista_podataka
 
 
 
 
 
 
data_list=[temperature, humidity, pressure]
data_list_index=0
data_list_length=len(data_list)
display_data(data_list[data_list_index])
 
changed=False
live_mode=True
ignore=False
id_of_last_reading=1
id_of_last_shown=8
update_display=False
while True:
    #print(f'Reading: {id_of_last_reading} - Shown: {id_of_last_shown}')
    #ovo vrtiti samo svakih 15 sekundi
    ts=get_timestamp()
    if (int(ts[-2:]))%5==0: #vrati na 15 poslije
        t,p,h=read_sensors()
        insert_data(ts,location,t,h,p)
        if live_mode==True:
            temperature, humidity, pressure=select_last_8()
            data_list=[temperature, humidity, pressure]
            id_of_last_shown=id_of_last_reading
        id_of_last_reading=select_data_find_last_id()
        update_display=True
 
    if live_mode==False and changed==True:
        #print(f'Reading: {id_of_last_reading} - Shown: {id_of_last_shown}')
        temperature, humidity, pressure=select_data_range(id_of_last_shown)
        data_list=[temperature, humidity, pressure]
        changed=False
 
    #####
    for event in sense.stick.get_events():
        #print(event)
        update_display=True
        if event.action=='pressed':
            if event.direction=='middle':
                data_list_index=(data_list_index+1)%data_list_length
            if event.direction=='left' and id_of_last_shown>8:
                id_of_last_shown-=1
                live_mode=False
                changed=True
            if event.direction=='right' and id_of_last_shown<id_of_last_reading:
                id_of_last_shown+=1
                live_mode=False
                changed=True
        if event.action=='held':
            if event.direction=='middle' and ignore==False:
                #print('srednji drzimo')
                data_list_index=(data_list_index-1)%data_list_length
                live_mode=True
                ignore=True
            if event.direction == 'left' and id_of_last_shown > 8:
                id_of_last_shown = max(8,id_of_last_shown - 8)
                live_mode = False
                changed = True
            if event.direction == 'right' and id_of_last_shown < id_of_last_reading:
                id_of_last_shown = min(id_of_last_reading, id_of_last_shown + 8)
                live_mode = False
                changed = True
        if event.action=='released':
            if event.direction=='middle':
                #print('srednji pusten')
                ignore=False     
 
    if update_display:   
        time.sleep(1)
        display_data(data_list[data_list_index])
        update_display=False
 
 
 
#select_data_find_last_id()
#select_data_range(300)