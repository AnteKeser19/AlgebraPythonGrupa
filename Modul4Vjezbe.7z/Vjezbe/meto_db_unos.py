import sqlite3
import datetime as dt
from sense_emu import SenseHat

sense = SenseHat()

sc = sqlite3.connect('Meteodata.db')
cursor = sc.cursor()


cursor.execute('''CREATE TABLE IF NOT EXISTS meteo (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 timestamp TEXT,
                 temperature INTEGER,
                 humidity INTEGER,
                 pressure INTEGER
             )''')
sc.commit()

interval = dt.timedelta(seconds=15)

try:
    while True:
        start_time = dt.datetime.now()

        temperature = round(sense.get_temperature())
        humidity = round(sense.get_humidity())
        pressure = round(sense.get_pressure())
        
        timestamp = start_time.isoformat()
        
        cursor.execute('''INSERT INTO meteo (timestamp, temperature, humidity, pressure)
                     VALUES (?, ?, ?, ?)''', (timestamp, temperature, humidity, pressure))
        sc.commit()
        
        print(f"Upisano: {timestamp}, {temperature}C, {humidity}%, {pressure}hPa")
        
        next_time = start_time + interval
        while dt.datetime.now() < next_time:
            pass  

except sqlite3.Error as e:
    print("Greška.",e)

finally:
    if sc:
        sc.close()
