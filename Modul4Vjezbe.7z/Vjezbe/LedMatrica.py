#from sense_hat import SenseHat
#sense = SenseHat()


# sense.show_message()
# sense.show_letter()
# sense.set_pixel()
# sense.set_pixels()


import time
from sense_emu import SenseHat
sense = SenseHat()

#sense.show_message('Moja prva poruka u Sense Hatu')

plavo = (0,0,255) # (R,G,B) u rasponu od 0 do 255
#sense.show_message('Plavi tekst',text_colour=plavo)

pozadina = (0,255,0)

'''
while True:
    sense.show_message('Plavo na zelenom',
                       text_colour=plavo,
                       scroll_speed=0.05,
                       back_colour = pozadina)
'''

sense.show_letter('P',
                  text_colour=plavo,
                  back_colour=pozadina)

time.sleep(3)

sense.set_pixel(0,2,(255,0,0))
time.sleep(3)
sense.clear()

R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0,)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)

slika=[
    G,G,G,G,G,G,G,G,
    R,R,R,R,R,R,R,R,
    R,R,R,R,R,R,R,R,
    W,W,W,W,W,W,W,W,
    W,W,W,W,W,W,W,W,
    B,B,B,B,B,B,B,B,
    B,B,B,B,B,B,B,B,
    G,G,G,G,G,G,G,G
]

sense.set_pixels(slika)
sense.clear()

smiley = [
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,K,Y,K,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,K,Y,Y,Y,K,Y,Y,
    Y,Y,K,K,K,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    ]

sense.set_pixels(smiley)
time.sleep(3)
sad=[
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,K,Y,K,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,K,K,K,K,K,Y,Y,
    Y,K,Y,Y,Y,K,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y
    ]

sense.set_pixels(sad)
time.sleep(3)

flat=[
   Y,Y,Y,Y,Y,Y,Y,Y,
   Y,Y,Y,Y,Y,Y,Y,Y,
   Y,Y,K,Y,K,Y,Y,Y,
   Y,Y,Y,Y,Y,Y,Y,Y,
   Y,K,K,K,K,K,Y,Y,
   Y,Y,Y,Y,Y,Y,Y,Y,
   Y,Y,Y,Y,Y,Y,Y,Y,
   Y,Y,Y,Y,Y,Y,Y,Y
    ]

sense.set_pixels(flat)

#sense.set_rotation(90)

kutevi = [0,90,180,270,0,90,180,270,0]

for kut in kutevi:
    sense.set_rotation(kut)
    time.sleep(0.5)
    
    

sense.show_letter('P',
                  text_colour=plavo,
                  back_colour=pozadina)

time.sleep(1)
sense.flip_h()
time.sleep(1)
sense.flip_v()


    
    
    