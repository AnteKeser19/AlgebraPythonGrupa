import time
import random 
 
from sense_emu import SenseHat
sense=SenseHat()
 
sense.clear()
 
R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
 
boje=[R,G,B,W,C,M,Y]
 
x=0 # lijevo
y=0 # gore
tocka=[x,y]
boja=boje[0]
 
sense.set_pixel(x,y,boja)
 
 
while True:
    naredba=input('Unesi WASD za navigaciju: ').lower()
    if naredba=='w':
        y-=1
        if y==-1:
            y=0
    elif naredba=='s':
        y+=1
        if y==8:
            y=7
    elif naredba=='a':
        x-=1
        if x==-1:
            x=0
    elif naredba=='d':
        x+=1
        if x==8:
            x=7
    elif naredba == 'c':
        indeks_boje +=1
        if indeks_boje == len(boje):
            indeks_boje=0
            boja = boje[indeks_boje]
        sense.clear()
        sense.set_pixel(x,y,boja)
    sense.clear()
    sense.set_pixel(x,y,boja)
