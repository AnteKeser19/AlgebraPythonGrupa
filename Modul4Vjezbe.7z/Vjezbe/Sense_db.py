import sqlite3
import datetime as dt
import time
from sense_emu import SenseHat

sense=SenseHat()
sense.clear()

database_name = "Meteodata2.db"

def get_timestamp():
    
    timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return timestamp

location = 'Home'

 
create_table_query = '''CREATE TABLE IF NOT EXISTS Meteo (
                      id INTEGER PRIMARY KEY,
                      timestamp TEXT NOT NULL,
                      location TEXT,
                      temperature REAL,
                      humidity REAL,
                      pressure REAL);'''

insert_data_query = '''INSERT INTO Meteo (timestamp, location, temperature, humidity, pressure)
                     VALUES (?,?,?,?,?)'''

select_data_query = ''' SELECT * FROM Meteo'''

select_data_where_query = '''SELECT temperature,humidity,pressure FROM Meteo WHERE ...'''

select_data_limit_8_query = '''SELECT * FROM
                             (SELECT * FROM Meteo ORDER BY id  DESC LIMIT 8)
                              ORDER BY id ASC;'''

def create_data_table():
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(create_table_query)
        sc.commit()
        cursor.close()
        
    except sqlite3.Error as e:
        print(e)
        
    finally:
        if sc:
            sc.close()
            
def insert_data(timestamp,loc,temp, hum, pres):
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(insert_data_query,(timestamp,loc,temp,hum,pres))
        sc.commit()
        cursor.close()
        
    except sqlite3.Error as e:
        print(e)
        
    finally:
        if sc:
            sc.close()
 
def select_all_data():
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_data_query)
        records = cursor.fetchall()
        print(records)
        cursor.close()
        
    except sqlite3.Error as e:
        print(e)
        
    finally:
        if sc:
            sc.close()
            
def select_eight_data():
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_data_limit_8_query)
        records = cursor.fetchall()
        print(records)
        data = [[],[],[]]
        for record in records:
             data[0].append(record[3])
             data[1].append(record[4])
             data[2].append(record[5])
        cursor.close()
        
    except sqlite3.Error as e:
        data = [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]]
        print(e)
        
    finally:
        if sc:
            sc.close()
        return data


def read_sensors():
    temperature=round(sense.get_temperature(),0)
    pressure=round(sense.get_pressure(),0)
    humidity=round(sense.get_humidity(),0)
    return temperature,pressure,humidity
            
create_data_table()         
'''        
while True:
    #t = float(input("Temp: "))
    #h = float(input("Hum: "))
    #p = float(input("Pres: "))
    ts = get_timestamp()
    t,p,h = read_sensors()
    insert_data(ts,location,t,h,p)
    izlaz = input('x za izlaz').lower()
    if izlaz == 'x':
        break
   
'''
#select_all_data()
#print()
lista_podataka=select_eight_data()
print()
print(lista_podataka)
temperature, humidity , pressure = lista_podataka


#byte size
 
#range piksela
def vrange(vmin, vmax):
    try:
        vmin=int(vmin)
        vmax=int(vmax)
    except:
        return False,1,20 # neuspjesno izvodjenje, step=1, base=20 (testirati u gl.prog T/F)
    step=((vmax-vmin)//8)+1 # npr. 27-20=7//8=0->+1, step=1, 32-20=12//8=1->+1, step=2, itd.
    base=(vmin//5)*5 # npr. 23//5=4*5=20, 27//5=5*5=25
    if (vmax-base)>(7*step): # npr. vmin=23,vmax=30,step=1,base=20,vmax(out of range)
        base=vmin #base=23->1px... vmax=30->8px
    return True,step,base
 
#br_piksela (range od do) po vertikali u rasponu od 7 do 0 (indeksi)
def pixel_range(value, step, base): # value->iscitana vrijednost, step i base iz range f-je
    try:
        value=int(value)
    except:
        return False, 0, 7 # neuspjesno izvodjenje, px_index_gore=0, px_index_dolje=7
    npx=((value-base)//step)+1 # npr. 24-20=4//1=4+1=5->gori 5px (7->20,6,5,4,3->24)
    #px_index=(8-npx,7) #npr. npx=5 -> index_gore=8-5=3, index_dolje=7
    return True, 8-npx, 7
 
def draw_column(icolumn,irowmin,irowmax,color=(0,255,0)): # mora biti procisceno (int)
    for irow in range(irowmin,irowmax+1):
        sense.set_pixel(icolumn, irow, color)
 
def display_data(data_list):
    sense.clear()
    ok,step,base=vrange(min(data_list),max(data_list))
    #print(ok,step,base)
    print(f'Minimum je: {base}\tPiksel je: {step}')
    for icolumn, value in enumerate(data_list):
        ok,irowmin,irowmax=pixel_range(value,step,base)
        draw_column(icolumn,irowmin,irowmax)

sense.clear()
# generirati liste s tocno 8 zapisa koje ce se proslijediti u f-ju
# dummy podaci za test su ispod


'''
temperature=[15.6, 17.2, 18.1, 20.1, 19.5, 18.3, 17.3, 16.7] 
humidity=[45.3, 50.2, 44.8, 42.7, 49.3, 53.5, 51.0, 49.4]
pressure=[1013, 1010, 1012, 1008, 1005, 1000, 997, 1004]
'''

'''
display_data(temperature)
time.sleep(5)
display_data(humidity)
time.sleep(5)
display_data(pressure)
'''

while True:
    ts = get_timestamp()
    t,p,h = read_sensors()
    insert_data(ts,location,t,h,p)
    temperature, humidity , pressure = select_eight_data()
    print(temperature)
    display_data(temperature)
    time.sleep(2)
    print(humidity)
    display_data(humidity)
    time.sleep(2)
    print(pressure)
    display_data(pressure)
    time.sleep(2)

'''
data_list = [temperature,humidity,pressure]
data_list_index = 0
data_list_length=len(data_list)
display_data(data_list[data_list_index])

update_display = False

while True:
    for event in sense.stick.get_events():
        update_display = True
        if event.action == 'pressed':
            if event.direction == 'middle':
                data_list_index = (data_list_index + 1) % data_list_length
                
    if update_display:
        time.sleep(1)
        display_data(data_list[data_list_index])
        update_display = False
'''             


