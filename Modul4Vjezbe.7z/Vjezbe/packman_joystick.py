import time
import random
 
from sense_emu import SenseHat
sense=SenseHat()
 
sense.clear()
 
R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
 
boje=[R,G,B,W,C,M,Y]
 
x=0 # lijevo
y=0 # gore
tocka_igrac=[x,y]
tocka_racunalo=[random.randint(0,7), random.randint(0,7)]
indeks_boje=0
boja_igrac=boje[indeks_boje]
boja_racunalo=(random.randint(0,255),random.randint(0,255),random.randint(0,255))
 
sense.set_pixel(tocka_igrac[0],tocka_igrac[1],boja_igrac)
sense.set_pixel(tocka_racunalo[0],tocka_racunalo[1],boja_racunalo)

    
while True:
    x,y=tocka_igrac
    for event in sense.stick.get_events():
        if event.action =='pressed':
            if event.direction == 'up':
                y-=1
                if y==-1:
                    y=0
            elif event.direction == 'down':
                y+=1
                if y==8:
                    y=7
            elif event.direction == 'left':
                x-=1
                if x==-1:
                    x=0
            elif event.direction == 'right':
               x+=1
               if x==8:
                    x=7
            elif event.direction == 'middle':
                   pass
    tocka_igrac=[x,y]
    if tocka_igrac==tocka_racunalo:
        print('nasli su se')
        boja_igrac=boja_racunalo
        tocka_racunalo=[random.randint(0,7), random.randint(0,7)]
        boja_racunalo=(random.randint(0,255),random.randint(0,255),random.randint(0,255))
 
    sense.clear()
    sense.set_pixel(tocka_igrac[0],tocka_igrac[1],boja_igrac)
    sense.set_pixel(tocka_racunalo[0],tocka_racunalo[1],boja_racunalo)
    time.sleep(0.2)