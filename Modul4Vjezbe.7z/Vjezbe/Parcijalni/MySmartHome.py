import tkinter as tk
import json
import requests
from sense_emu import SenseHat
from PIL import Image, ImageTk
import random
import datetime as dt
import sqlite3

sense = SenseHat()
sense.clear()


def run_sk():
    import smartkey

def get_location():
    select = '''SELECT * FROM HouseInfo'''
    database = 'Smarthome.db'
    
    try:
        sc = sqlite3.connect(database)
        cursor = sc.cursor()
        cursor.execute(select)
        records = cursor.fetchall()
        for record in records:
            Location = f'{record[1]}'
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
    return Location

def create_sensor_table():
    create_table = '''CREATE TABLE IF NOT EXISTS SensorData(
                      id INTEGER PRIMARY KEY,
                      Time TEXT NOT NULL,
                      Type TEXT NOT NULL,
                      Value_House TEXT NOT NULL,
                      Value_out TEXT NOT NULL);'''
        
    database_name = 'Smarthome.db'
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(create_table)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
    


def startup_table():
    create_table = '''CREATE TABLE IF NOT EXISTS HouseInfo(
                      id INTEGER PRIMARY KEY,
                      Location TEXT NOT NULL,
                      Adress TEXT NOT NULL UNIQUE,
                      PostalCode TEXT NOT NULL UNIQUE,
                      Owner TEXT NOT NULL,
                      SmartID TEXT NOT NULL UNIQUE,
                      Version TEXT NOT NULL);'''
    database_name = 'Smarthome.db'
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(create_table)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
    
    insert = '''INSERT INTO HouseInfo (Location,Adress,PostalCode,Owner,SmartID,Version)
                VALUES(?,?,?,?,?,?)'''
    select = '''SELECT * FROM HouseInfo WHERE SmartID=?'''
    info = ('Knin','Moja Adresa','0000','Ime Prezime','312312321','v.1.2.0')
    
    InfoTable = [
        info
    ]
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        for inf in InfoTable:
            cursor.execute(select,(info[4],))
            postoji = cursor.fetchone()
            if postoji:
                pass
            else:
                cursor.execute(insert,info)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()

update_interval = 1000  
update_task = None  
Location = get_location()
Version_label = None
cc = 0

dev_widgets = []  

def update_time():
    global Date, Time
    Date = dt.datetime.now().strftime("%d.%m.%Y.")
    Time = dt.datetime.now().strftime("%H:%M")
    Date_label.config(text=f'{Date}')
    Time_label.config(text=f'{Time}')
    root.after(update_interval, update_time)  

def show_main_menu():
    global update_task, Version_label, dev_widgets
    Header.config(text='MySmartHome')
    weather.place(x=200, y=250)
    humidity.place(x=30, y=250)
    pressure.place(x=410, y=250)
    info.place(x=400,y=120)
    sk.place(x=80,y=120)
    Loc_label.place(x=30, y=10)
    Date_label.place(x=460, y=10)
    Time_label.place(x=490, y=40)
    
    for widget in root.winfo_children():
        if isinstance(widget, tk.Button) and widget.cget("text") == "Back":
            widget.place_forget()
            
    if update_task is not None:
        root.after_cancel(update_task)
        update_task = None

    if Version_label is not None:
        Version_label.destroy()
        Version_label = None

    for widget in root.winfo_children():
        if isinstance(widget, tk.Label) and widget != Header and widget not in (Loc_label, Date_label, Time_label):
            widget.destroy()

    for widget in dev_widgets:
        if widget.winfo_exists():
            widget.place_forget()

def hide_main_menu():
    weather.place_forget()
    humidity.place_forget()
    pressure.place_forget()
    info.place_forget()
    Loc_label.place_forget()
    Time_label.place_forget()
    Date_label.place_forget()
    sk.place_forget()

def house_info():
    global update_task, Location_label, Adress_label, Postal_label, ID_label, Owner_label, Version_label
    select = '''SELECT * FROM HouseInfo'''
    database = 'Smarthome.db'
    
    try:
        sc = sqlite3.connect(database)
        cursor = sc.cursor()
        cursor.execute(select)
        records = cursor.fetchall()
        for record in records:
            Location_label = tk.Label(root,text=f'Mjesto: {record[1]}', font=('Seoge UI', 14), fg='white', bg='dim gray')
            Location_label.pack(padx=5,pady=5)
            Adress_label = tk.Label(root, text=f'Adresa: {record[2]}', font=('Seoge UI', 14), fg='white', bg='dim gray')
            Adress_label.pack(padx=5,pady=6)
            Postal_label = tk.Label(root, text=f'Poštanski broj: {record[3]}', font=('Seoge UI', 14), fg='white', bg='dim gray')
            Postal_label.pack(padx=5,pady=7)
            Owner_label = tk.Label(root, text=f'Vlasnik: {record[4]}', font=('Seoge UI', 14), fg='white', bg='dim gray')
            Owner_label.pack(padx=5,pady=8)
            ID_label = tk.Label(root, text=f'Smart House ID: {record[5]}', font=('Seoge UI', 14), fg='white', bg='dim gray')
            ID_label.pack(padx=5,pady=9)
            Version_label = tk.Button(root,text=f'Smart House Version: {record[6]}', font=('Seoge UI', 14), fg='white', bg='dim gray',command=when_clicked)
            Version_label.pack(padx=5,pady=10)
            
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
            
    Header.config(text='House Info')
    hide_main_menu()

    back_button = tk.Button(root, text="Back", font=('Segoe UI', 14), command=show_main_menu)
    back_button.place(x=500, y=250)

    update_task = root.after(1)


def when_clicked():
    global cc
    cc += 1
    if cc == 10:
        dev_options()
        
def dev_hide_prev():
    global Location_label, Adress_label, Postal_label, ID_label, Owner_label, Version_label
    Location_label.pack_forget()
    Adress_label.pack_forget()
    Postal_label.pack_forget()
    ID_label.pack_forget()
    Owner_label.pack_forget()
    Version_label.pack_forget()

def handle_save(event):
    Adress = Adress_entry.get()
    Postal = Postal_entry.get()
    Owner = Owner_entry.get()
    
    update = '''UPDATE HouseInfo SET Location=?, Adress=?,PostalCode=?,Owner=?'''
    database_name = 'Smarthome.db'
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(update,(Location,Adress,Postal,Owner))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
    
def dev_options():
    global update_task, cc, Location_entry, Adress_entry, Postal_entry, Owner_entry, dev_widgets
    dev_hide_prev()
    hide_main_menu()
    Header.config(text='Developer Settings')
    cc = 0
    Adress_label = tk.Label(root,text='Adress',font=('Segoe UI',14),borderwidth=1,relief='solid',width=10)
    Adress_label.place(x=150,y=50)
    Adress_entry = tk.Entry(bd=2)
    Adress_entry.place(x=300,y=50)
    Postal_label = tk.Label(root,text='Postal Code',font=('Segoe UI',14),borderwidth=1,relief='solid',width=10)
    Postal_label.place(x=150,y=100)
    Postal_entry = tk.Entry(bd=2)
    Postal_entry.place(x=300,y=100)
    Owner_label = tk.Label(root,text='Owner',font=('Segoe UI',14),borderwidth=1,relief='solid',width=10)
    Owner_label.place(x=150,y=150)
    Owner_entry = tk.Entry(bd=2)
    Owner_entry.place(x=300,y=150)
    save = tk.Button(root,text='Save',font=('Segoe UI',14),borderwidth=1,relief='solid',width=10)
    save.place(x=300,y=200)
    save.bind('<Button-1>',handle_save)
    
    dev_widgets = [Adress_label, Adress_entry, Postal_label, Postal_entry, Owner_label, Owner_entry,save]

    back_button = tk.Button(root, text="Back", font=('Segoe UI', 14), command=show_main_menu)
    back_button.place(x=500, y=250)

def pressure_data():
    global image, update_task
    Header.config(text='Pressure')
    hide_main_menu()
    
    Type = 'Pressure'
    time = dt.datetime.now().strftime("%d:%m:%Y %H:%M:%S")

    URL = 'https://api.open-meteo.com/v1/forecast?latitude=44.0406&longitude=16.1966&current=temperature_2m,relative_humidity_2m,surface_pressure&hourly=temperature_2m,relative_humidity_2m,rain,weather_code,surface_pressure,visibility&timezone=Europe%2FBerlin&forecast_days=1'
    response = requests.get(URL)
    json_string = response.text
    dict_json = json.loads(json_string)


    in_press = round(sense.get_pressure(), 1)
    out_press = dict_json["current"]["surface_pressure"]

    Out_Pressure = tk.Label(root, text=f'Vanjski Pritisak: {out_press}',
                            font=('Segoe UI', 14), bg='dim gray', fg='peach puff')
    Out_Pressure.place(x=30, y=50)

    In_Pressure = tk.Label(root, text=f'Unutarnji Pritisak: {in_press}',
                           font=('Segoe UI', 14), bg='dim gray', fg='peach puff')
    In_Pressure.place(x=310, y=50)

    if in_press > 1015 or in_press < 1005:
        image = Image.open('Weird.png')
    else:
        image = Image.open('Happy.png')
        
    image = ImageTk.PhotoImage(image)
    image_label = tk.Label(root, image=image, bg='dim gray')
    image_label.place(x=180, y=90)

    back_button = tk.Button(root, text="Back", font=('Segoe UI', 14), command=show_main_menu)
    back_button.place(x=500, y=250)

    insert = '''INSERT INTO SensorData(Time,Type,Value_House,Value_Out) VALUES (?,?,?,?)'''
    database_name = 'Smarthome.db'
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(insert,(time,Type,in_press,out_press))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close() 

    update_task = root.after(update_interval, pressure_data)

def humidity_data():
    global image, update_task
    Header.config(text='Humidity')
    hide_main_menu()
    
    Type = 'Humidity'
    time = dt.datetime.now().strftime("%d:%m:%Y %H:%M:%S")
    
    URL = 'https://api.open-meteo.com/v1/forecast?latitude=44.0406&longitude=16.1966&current=temperature_2m,relative_humidity_2m,surface_pressure&hourly=temperature_2m,relative_humidity_2m,rain,weather_code,surface_pressure,visibility&timezone=Europe%2FBerlin&forecast_days=1'
    response = requests.get(URL)
    json_string = response.text
    dict_json = json.loads(json_string)
    
    in_hum = round(sense.get_humidity(), 1)
    out_hum = dict_json["current"]["relative_humidity_2m"]

    Out_Humidity = tk.Label(root, text=f'Vanjska Vlažnost: {out_hum}',
                            font=('Segoe UI', 14), bg='dim gray', fg='peach puff')
    Out_Humidity.place(x=30, y=50)

    In_Humidity = tk.Label(root, text=f'Unutarnja Vlažnost: {in_hum}',
                           font=('Segoe UI', 14), bg='dim gray', fg='peach puff')
    In_Humidity.place(x=310, y=50)

    if 30 < in_hum < 50:
        image = Image.open('Happy.png')
    else:
        image = Image.open('Weird.png')
        
    image = ImageTk.PhotoImage(image)
    image_label = tk.Label(root, image=image, bg='dim gray')
    image_label.place(x=180, y=90)

    back_button = tk.Button(root, text="Back", font=('Segoe UI', 14), command=show_main_menu)
    back_button.place(x=500, y=250)

    insert = '''INSERT INTO SensorData(Time,Type,Value_House,Value_Out) VALUES (?,?,?,?)'''
    database_name = 'Smarthome.db'
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(insert,(time,Type,in_hum,out_hum))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close() 

    update_task = root.after(update_interval, humidity_data)

def weather_data():
    global image, update_task
    Header.config(text='Weather')
    hide_main_menu()
    
    Type = 'Temperature'
    time = dt.datetime.now().strftime("%d:%m:%Y %H:%M:%S")

    URL = 'https://api.open-meteo.com/v1/forecast?latitude=44.0406&longitude=16.1966&current=temperature_2m,relative_humidity_2m,surface_pressure&hourly=temperature_2m,relative_humidity_2m,rain,weather_code,surface_pressure,visibility&timezone=Europe%2FBerlin&forecast_days=1'
    response = requests.get(URL)
    json_string = response.text
    dict_json = json.loads(json_string)

    Out_Temp = dict_json["current"]["temperature_2m"]

    Out_Temperature = tk.Label(root, text=f'Vanjska Temperatura: {Out_Temp}',
                               font=('Segoe UI', 14), bg='dim gray', fg='peach puff')
    Out_Temperature.place(x=10, y=50)

    temp = round(sense.get_temperature(), 1)

    In_Temperature = tk.Label(root, text=f'Unutarnja Temperatura: {temp}',
                              font=('Segoe UI', 14), bg='dim gray', fg='peach puff')
    In_Temperature.place(x=300, y=50)

    if 15 <= temp < 30:  
        image = Image.open('Happy.png')
    elif temp > 30:
        image = Image.open('Hot.png')
    else:
        image = Image.open('Cold.png')

    image = ImageTk.PhotoImage(image)
    image_label = tk.Label(root, image=image, bg='dim gray')
    image_label.place(x=180, y=90)

    back_button = tk.Button(root, text="Back", font=('Segoe UI', 14), command=show_main_menu)
    back_button.place(x=500, y=250)
    
    insert = '''INSERT INTO SensorData(Time,Type,Value_House,Value_Out) VALUES (?,?,?,?)'''
    database_name = 'Smarthome.db'
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(insert,(time,Type,temp,Out_Temp))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
            
    
    update_task = root.after(update_interval, weather_data)

root = tk.Tk()
root.title('MySmartHome')
root.geometry('600x300')
root.configure(background='dim gray')

Header = tk.Label(root, text='MySmartHome', font=('Segoe UI', 24), fg='peach puff', bg='dim gray')
Header.pack()

weather = tk.Button(root, text='Weather Forecast', font=('Segoe UI', 14), command=weather_data)
weather.place(x=200, y=250)

humidity = tk.Button(root, text='Humidity Info', font=('Segoe UI', 14), command=humidity_data)
humidity.place(x=30, y=250)

pressure = tk.Button(root, text='Pressure Info', font=('Segoe UI', 14), command=pressure_data)
pressure.place(x=410, y=250)

info = tk.Button(root,text='House Info',font=('Segoe UI', 14), command=house_info)
info.place(x=400,y=120)

Loc_label = tk.Label(root,text=f'{Location}',font=('Segoe UI',15),fg='white',bg='dim gray')
Loc_label.place(x=30,y=10)

Date_label = tk.Label(root,text='',font=('Segoe UI',15),fg='white',bg='dim gray')
Date_label.place(x=460,y=10)

Time_label = tk.Label(root,text='',font=('Segoe UI',15),fg='white',bg='dim gray')
Time_label.place(x=490,y=40)

sk = tk.Button(root,text='Smart key',font=('Segoe UI',14), command=run_sk)
sk.place(x=80,y=120)

update_time()
create_sensor_table()
startup_table()
root.update_idletasks()
root.mainloop()
