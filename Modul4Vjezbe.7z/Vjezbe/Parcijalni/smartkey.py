import tkinter as tk
import sqlite3
 
pin_input = ''
 
def startup_table():
    create_table = '''CREATE TABLE IF NOT EXISTS Korisnici(
                      id INTEGER PRIMARY KEY,
                      name TEXT NOT NULL,
                      surname TEXT NOT NULL,
                      pin TEXT NOT NULL UNIQUE,
                      status BOOLEAN NOT NULL);'''
    database_name = 'smartkey.db'
 
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(create_table)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print('Pogreška kod spajanja na bazu',e)
    finally:
        if sc:
            sc.close()
 
    insert = '''INSERT INTO Korisnici (name,surname,pin,status)
                VALUES(?,?,?,?)'''
    select = '''SELECT * FROM Korisnici WHERE pin=?'''
    database_name = 'smartkey.db'
    info = ('admin','admin','1111',1)
 
    loginKorisnici = [
        info
 
    ]
 
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        for korisnik in loginKorisnici:
            cursor.execute(select,(info[2],))
            postoji = cursor.fetchone()
            if postoji:
                pass
            else:
                cursor.execute(insert,info)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print('Pogreska kod spajanja na bazu',e)
    finally:
        if sc:
            sc.close()
 
def provjeri_pin(pin):
    database_name = 'smartkey.db'
    select_query = '''SELECT name, surname, status FROM Korisnici WHERE pin=?'''    
    try: 
        sc=sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_query,(pin,))
        korisnik = cursor.fetchone()
        cursor.close()
        return korisnik
    except sqlite3.Error as e:
        print('Pogreška kod spajanja na bazu',e)
    finally:
        if sc:
            sc.close()
 
 
def accept():
    global pin_input
    if len(pin_input) == 4:
        korisnik = provjeri_pin(pin_input)
        if korisnik:
            if pin_input =='1111':
                Main_text.config(text=f'Dobrodošao {korisnik[0]} {korisnik[1]}',
                                 fg='green')
                admin_yesno()
            elif korisnik[2]:
                Main_text.config(text=f'Dobrodošao {korisnik[0]} {korisnik[1]}',
                                 fg='green')
            else:
                Main_text.config(text='Korisnik nije aktivan!',
                                 fg='red')
        else:
            Main_text.config(text='Pogrešan PIN!',
                                 fg='red')
    else:
        Main_text.config(text='Neispravan unos PIN-a',
                         fg='red')
 
 
def zvono():
    Main_text.config(text='DING! DONG!\nNetko će uskoro otvoriti vrata :)',
                     font=('Segoe UI',20),
                     fg='green') 
 
def admin_yesno():
    global admin_label
    global yes
    global no
    admin_label = tk.Label(root,text='Želite li pristupiti admin meniju?',
                           font=('Segoe UI',24),
                           compound=tk.CENTER)
    admin_label.place(x=150,y=275)
    yes = tk.Button(root,text='Da',
                    command=admin_meni,
                    font=('Seoge UI',14),
                    compound=tk.LEFT)
    yes.place(x=225,y=325)
 
    no = tk.Button(root,text='Ne',
                    font=('Seoge UI',14),
                    compound=tk.LEFT,
                    command=negative)
    no.place(x=425,y=325)
 
def negative():
    admin_label.config(text='Odustali ste od pristupa admin meniju!!',
                       fg='red')
    admin_label.place_configure(x=100,y=275)
    yes.place_forget()
    no.place_forget()
    br1.configure(state='disabled')
    br2.configure(state='disabled')
    br3.configure(state='disabled')
    br4.configure(state='disabled')
    br5.configure(state='disabled')
    br6.configure(state='disabled')
    br7.configure(state='disabled')
    br8.configure(state='disabled')
    br9.configure(state='disabled')
    delete_all.configure(state='disabled')
    prihvat.configure(state='disabled')
 
def fill(ime,prezime,pin,aktivan):
    ime_entry.delete(0,tk.END)
    ime_entry.insert(0,ime)
    prezime_entry.delete(0,tk.END)
    prezime_entry.insert(0,prezime)
    pin_entry.delete(0,tk.END)
    pin_entry.insert(0,pin)
    aktivan = aktivan_entry.select()
 
def handle_odustani(event):
    ime_entry.delete(0,tk.END)
    prezime_entry.delete(0,tk.END)
    pin_entry.delete(0,tk.END)
    aktivan = aktivan_entry.deselect() 
 
def handle_izbrisi(event):
    ime = ime_entry.get()
    prezime = prezime_entry.get()
    pin = pin_entry.get()
    aktivan = active.get()
    delete = '''DELETE FROM Korisnici WHERE pin=?'''
    database_name = 'Smartkey.db'
    try:
        sc=sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(delete,(pin,))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print('Pogreška kod spajanja na bazu',e)
    finally:
        if sc:
            sc.close()
    ime_entry.delete(0,tk.END)
    prezime_entry.delete(0,tk.END)
    pin_entry.delete(0,tk.END)
    aktivan_entry.deselect()
 
def handle_spremi(event):
    ime = ime_entry.get()
    prezime = prezime_entry.get()
    pin = pin_entry.get()
    aktivan = active.get()
 
    if len(pin) != 4:
        Main_text.config(text='Pin mora sadržavati točno 4 znamenke!', fg='red')
        return
    elif pin.isdigit() == False:
        Main_text.config(text='Pin mora biti brojčani', fg='red')
        return
 
    select_query = '''SELECT id FROM Korisnici WHERE pin=?'''
    update_query = '''UPDATE Korisnici SET name=?, surname=?, pin=?, status=? WHERE id=?'''
    insert_query = '''INSERT INTO Korisnici (name, surname, pin, status) VALUES (?, ?, ?, ?)'''
    database_name = 'smartkey.db'
 
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
 
        cursor.execute(select_query, (pin,))
        korisnik = cursor.fetchone()
 
        if korisnik:
            cursor.execute(update_query, (ime, prezime, pin, aktivan, korisnik[0]))
        else:
            cursor.execute(insert_query, (ime, prezime, pin, aktivan))
 
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print('Pogreška kod spajanja na bazu', e)
    finally:
        if sc:
            sc.close()
 
    ime_entry.delete(0, tk.END)
    prezime_entry.delete(0, tk.END)
    pin_entry.delete(0, tk.END)
    aktivan_entry.deselect()
 
 
def admin_meni():
    yes.place_forget()
    no.place_forget()
    admin_label.place_forget()
    global ime_entry
    global prezime_entry
    global pin_entry
    global aktivan_entry
    global active
 
    select = '''SELECT * FROM Korisnici'''
    database = 'smartkey.db'
    try:
        sc = sqlite3.connect(database)
        cursor = sc.cursor()
        cursor.execute(select)
        records = cursor.fetchall()
        vertical_position = 325
        for record in records:
            korisnici = tk.Button(text=f'Ime: {record[1]} - Prezime: {record[2]}',
                                  font=('Segoe UI',14),
                                  compound=tk.LEFT,command=lambda
                                  ime = record[1],prezime=record[2],pin=record[3],aktivan=record[4]: fill(ime,prezime,pin,aktivan))
            korisnici.place(x=30,y=vertical_position)
            vertical_position +=50
        cursor.close()
    except sqlite3.Error as e:
        print('Greška kod spajanja na bazu')
    finally:
        if sc:
            sc.close()
 
    ime = tk.Label(root,text='Ime',font=('Segoe UI',20),borderwidth=1,relief='solid',width=10).place(x=225,y=75)
    ime_entry = tk.Entry(bd=10)
    ime_entry.place(x=425,y=75)
    prezime = tk.Label(root,text='Prezime',font=('Segoe UI',20),borderwidth=1,relief='solid',width=10).place(x=225,y=125)
    prezime_entry = tk.Entry(bd=10)
    prezime_entry.place(x=425,y=125)
    pin = tk.Label(root,text='Pin',font=('Segoe UI',20),borderwidth=1,relief='solid',width=10)
    pin.place(x=225,y=175)
    pin_entry = tk.Entry(bd=10)
    pin_entry.place(x=425,y=175)
    aktivan = tk.Label(root,text='Aktivan',font=('Segoe UI',20),borderwidth=1,relief='solid',width=10).place(x=225,y=225)
    active = tk.BooleanVar()
    aktivan_entry = tk.Checkbutton(root,variable=active)
    aktivan_entry.place(x=425,y=225)
    odustani = tk.Button(root,text='Odustani',font=('Segoe UI',14),borderwidth=10,relief='raised',width=7,bg='orange')
    odustani.place(x=625,y=75)
    odustani.bind('<Button-1>',handle_odustani)
    izbrisi = tk.Button(root,text='Izbriši',font=('Segoe UI',14),borderwidth=10,relief='raised',width=7,bg='red')
    izbrisi.place(x=750,y=75)
    izbrisi.bind('<Button-1>',handle_izbrisi)
    spremi = tk.Button(root,text='Spremi',font=('Segoe UI',14),borderwidth=10,relief='raised',width=7,bg='green')
    spremi.place(x=680,y=150)
    spremi.bind('<Button-1>',handle_spremi)
 
 
def n1():
    global pin_input
    pin_input +='1' 
 
def n2():
    global pin_input
    pin_input +='2' 
 
def n3():
    global pin_input
    pin_input +='3' 
 
def n4():
    global pin_input
    pin_input +='4' 
 
def n5():
    global pin_input
    pin_input +='5' 
 
def n6():
    global pin_input
    pin_input +='6' 
 
def n7():
    global pin_input
    pin_input +='7' 
 
def n8():
    global pin_input
    pin_input += '8'
 
def n9():
    global pin_input
    pin_input +='9'  
 
def clear():
    global pin_input
    pin_input = ''
 
def unlock():
    global br1
    global br2
    global br3
    global br4
    global br5
    global br6
    global br7
    global br8
    global br9
    global prihvat
    global delete_all
    kuc_kuc.place_forget()
    otkljucaj.place_forget()
    Main_text.config(text='Unesite PIN',
                     fg='Green')
    br1= tk.Button(root,text='1',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n1)
    br1.place(x=60,y=75)
    br2= tk.Button(root,text='2',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n2)
    br2.place(x=110,y=75)
    br3= tk.Button(root,text='3',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n3)
    br3.place(x=160,y=75)
    br4= tk.Button(root,text='4',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n4)
    br4.place(x=60,y=125)
    br5= tk.Button(root,text='5',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n5)
    br5.place(x=110,y=125)
    br6 = tk.Button(root,text='6',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n6)
    br6.place(x=160,y=125)
    br7 = tk.Button(root,text='7',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n7)
    br7.place(x=60,y=175)
    br8 = tk.Button(root,text='8',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n8)
    br8.place(x=110,y=175)
    br9 = tk.Button(root,text='9',
                    borderwidth=10,
                    relief=tk.RAISED,
                    compound=tk.LEFT,
                    command=n9)
    br9.place(x=160,y=175)
    delete_all = tk.Button(root,text='Clear',
                           borderwidth=10,
                           relief=tk.RAISED,
                           fg='white',
                           bg='red',
                           compound=tk.LEFT,
                           command=clear)
 
    delete_all.place(x=60,y=225)
    prihvat = tk.Button(root,text='Accept',
                       borderwidth=10,
                       relief=tk.RAISED,
                       fg='white',
                       bg='green',
                       compound=tk.LEFT,
                       command=accept)
    prihvat.place(x=130,y=225)
 
 
 
 
root = tk.Tk()
root.title('Parcijalni')
root.geometry('900x650')
 
kuc_kuc = tk.Button(root,text='Pozvoni',
                    font=('Seoge UI',14),
                    compound=tk.LEFT,
                    command=zvono)
kuc_kuc.place(x=60,y=75)
 
otkljucaj = tk.Button(root,text='Otkljucaj',
                      command= unlock,
                      font=('Segoe UI',14),
                      compound=tk.RIGHT)
otkljucaj.place(x=580,y=75)
 
Main_text = tk.Label(root,text='SmartKey',
                     font=('Segoe UI',24),
                     compound=tk.CENTER,
                     fg='Purple')
Main_text.pack()
 
