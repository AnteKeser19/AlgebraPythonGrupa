import sqlite3
import datetime as dt
import time
from sense_db_queries import *
from sense_db_display import *
 
sense.clear()
 
database_name='Meteodata.db'
 
def get_timestamp():
    #print(dt.datetime.now())
    timestamp=dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    #print(timestamp)
    return timestamp
 
location='Home'
 
 
# 
def create_data_table():
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(create_table_query)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
 
def insert_data(timestamp, loc, temp, humi, pres):
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(insert_data_query,(timestamp,loc,temp,humi,pres))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
 
 
def select_all_data():
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(select_data_query)
        records=cursor.fetchall()
        print(records)
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
 
def select_last_8():
    try:
        sc=sqlite3.connect(database_name)
        cursor=sc.cursor()
        cursor.execute(select_data_limit_8_query)
        records=cursor.fetchall()
        print(records)
        data=[[],[],[]] #t(3), h(4), p(5)
        for record in records:
            data[0].append(record[3])
            data[1].append(record[4])
            data[2].append(record[5])
        cursor.close()
    except sqlite3.Error as e:
        data=[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]]
        print(e)
    finally:
        if sc:
            sc.close()
        return data
 
def read_sensors():
    temperature=round(sense.get_temperature(),0)
    pressure=round(sense.get_pressure(),0)
    humidity=round(sense.get_humidity(),0)
    return temperature,pressure,humidity
 
 
create_data_table()
 
 
 
 
 
sense.clear()
 
 
lista_podataka=select_last_8()
print()
print(lista_podataka)
temperature, humidity, pressure=lista_podataka
 
 
'''
while True:
    ts=get_timestamp()
    t,p,h=read_sensors()
    insert_data(ts,location,t,h,p)
    temperature, humidity, pressure=select_last_8()
    print(temperature)
    display_data(temperature)
    time.sleep(2)
    print(humidity)
    display_data(humidity)
    time.sleep(2)
    print(pressure)
    display_data(pressure)
    time.sleep(2)
'''
 
 
 
 
 
data_list=[temperature, humidity, pressure]
data_list_index=0
data_list_length=len(data_list)
display_data(data_list[data_list_index])
 
'''
'''
 
update_display=False
while True:
    #ovo vrtiti samo svakih 15 sekundi
    ts=get_timestamp()
    if (int(ts[-2:]))%15==0:
        t,p,h=read_sensors()
        insert_data(ts,location,t,h,p)
        temperature, humidity, pressure=select_last_8()
        data_list=[temperature, humidity, pressure]
        update_display=True
    #####
    for event in sense.stick.get_events():
        print(event)
        update_display=True
        if event.action=='pressed':
            if event.direction=='middle':
                data_list_index=(data_list_index+1)%data_list_length
    if update_display:   
        time.sleep(1)
        display_data(data_list[data_list_index])
        update_display=False