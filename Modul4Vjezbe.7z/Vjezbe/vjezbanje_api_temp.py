import json
import requests
from sense_emu import SenseHat
import tkinter as tk




root = tk.Tk()
root.title('Gui Prikaz')
root.geometry('150x50')


sense=SenseHat()
sense.clear()

URL = 'https://api.open-meteo.com/v1/forecast?latitude=44.037102&longitude=16.197300&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m'

response = requests.get(URL)
json_string = response.text
dict_json = json.loads(json_string)




#print(f'Temperatura: {dict_json["hourly"]["temperature_2m"][0]}')

lista_temperature = dict_json["hourly"]["temperature_2m"]
lista_humidity = dict_json["hourly"]["relative_humidity_2m"]


index = 0



red = (255,0,0)
orange = (255,135,0)
green = (240,255,0)
better_green = (54,255,0)
light_green = (0,255,61)
light_blue = (0,255,237)
baby_blue = (0,183,255)
blue = (0,0,255)
dark_blue = (17,10,77)
black = (0,0,0)
white = (255,255,255)

def display_temperature():
    boja = light_green
    temp = lista_temperature[index]
    height = max(1, int(temp // 5))
    
    if temp > 19:
        boja = green
    elif temp < 19:
        boja = baby_blue
        
    for j in range(height):
        if 7 - j >= 0:
            sense.set_pixel(0, 7 - j,boja)

            
def display_humidity():
    boja = blue
    hum = lista_humidity[index]
    height = max(1, int(hum // 10))
    for j in range(height):
        if 7 - j >= 0:
            sense.set_pixel(0, 7 - j,boja)
            
temperature_label = tk.Label(root,text=f'{lista_temperature[index]} °C',
                             font=('Segoe UI',14))
temperature_label.pack()

humidity_label = tk.Label(root,text=f'{lista_humidity[index]} %',
                          font=('Segoe UI', 14))
humidity_label.pack()
          
def change_things():
    global index
    display_mode = 0

 
    while True:
        if display_mode == 0:
            display_temperature()
        elif display_mode == 1:
            display_humidity()
         
        root.update_idletasks()
            
        for event in sense.stick.get_events():
            if event.action == 'pressed' and event.direction == 'middle':
                display_mode = (display_mode +1) % 2
                print(display_mode)
            elif event.action == 'pressed' and event.direction == 'right':
                if display_mode == 0:
                    index = (index +1) % len(lista_temperature)
                    print(lista_temperature[index])
                    temperature_label.config(text=f'{lista_temperature[index]} °C')
                    sense.clear()
                elif display_mode == 1:
                    index = (index+1) % len(lista_humidity)
                    print(lista_humidity[index])
                    humidity_label.config(text=f'{lista_humidity[index]} %')
                    sense.clear()
            elif event.action == 'pressed' and event.direction == 'left':
                if display_mode == 0:
                    index = (index -1) % len(lista_temperature)
                    print(lista_temperature[index])
                    temperature_label.config(text=f'{lista_temperature[index]} °C')
                    sense.clear()
                elif display_mode == 1:
                    index = (index-1) % len(lista_humidity)
                    print(lista_humidity[index])
                    humidity_label.config(text=f'{lista_humidity[index]} %')
                    sense.clear()
        
   






change_things()
root.mainloop()
#display_temperature(temperature)
#display_humidity(humidity)