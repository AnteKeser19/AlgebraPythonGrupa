import time
import random



 
from sense_emu import SenseHat
sense=SenseHat()
 
sense.clear()
 
R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
 
boje=[R,G,B,W,C,M,Y]

dogadjaji = sense.stick.get_events()
print(dogadjaji)
'''
while True:
    events = sense.stick.get_events()
    print(events)
    time.sleep(1)
'''
'''
while True:
    for event in sense.stick.get_events():
    print(event.direction,event.action)
'''
while True:
    for event in sense.stick.get_events():
        if event.action =='pressed':
            if event.direction == 'up':
                sense.show_letter('U')
            elif event.direction == 'down':
                   sense.show_letter('D')
            elif event.direction == 'left':
                   sense.show_letter('L')
            elif event.direction == 'right':
                   sense.show_letter('R')
            elif event.direction == 'middle':
                   sense.show_letter('M')
            time.sleep(1)
