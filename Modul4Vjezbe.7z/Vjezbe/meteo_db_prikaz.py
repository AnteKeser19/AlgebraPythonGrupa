import sqlite3
from sense_emu import SenseHat
import time
import tkinter as tk

sense = SenseHat()
sense.clear()

root = tk.Tk()
root.title("GUI Prikaz")
root.geometry("300x200")

database_name = 'Meteodata.db'

lista_temperature = []
lista_humidity = []
lista_pressure = []

try:
    sc = sqlite3.connect(database_name)
    cursor = sc.cursor()
    select = '''SELECT * FROM meteo'''
    cursor.execute(select)
    records = cursor.fetchall()
    for record in records:
        temperatura = record[2]
        lista_temperature.append(temperatura)
        
        humidity = record[3]
        lista_humidity.append(humidity)
        
        pressure = record[4]
        lista_pressure.append(pressure)
        
    cursor.close()
    
except sqlite3.Error as e:
    print('Greška:', e)
    
finally:
    if sc:
        sc.close()
              
display_mode = 0        
current_position = max(0, len(lista_temperature) - 8)

min_temp_label = tk.Label(root, font=('Segoe UI', 14))
min_humidity_label = tk.Label(root, font=('Segoe UI', 14))
min_pressure_label = tk.Label(root, font=('Segoe UI', 14))

max_temp_label = tk.Label(root, font=('Segoe UI', 14))
max_humidity_label = tk.Label(root, font=('Segoe UI', 14))
max_pressure_label = tk.Label(root, font=('Segoe UI', 14))

def update_max_label(label, text):
    max_temp_label.pack_forget()
    max_humidity_label.pack_forget()
    max_pressure_label.pack_forget()
    
    label.config(text=text)
    label.pack()

def update_min_label(label, text):
    min_temp_label.pack_forget()
    min_humidity_label.pack_forget()
    min_pressure_label.pack_forget()

    label.config(text=text)
    label.pack()

def display_temperature(lista_temperature):
    global current_position
    lista_temperature = lista_temperature[current_position:current_position + 8]

    max_temp = max(lista_temperature)
    min_temp = min(lista_temperature)
    temp_range = max_temp - min_temp

    if temp_range <= 8:
        step = 1
    elif temp_range <= 16:
        step = 2
    else:
        step = 3  
    
    update_max_label(max_temp_label, f'Najviša temperatura je {max_temp} °C')
    update_min_label(min_temp_label, f'Najniža temperatura je {min_temp} °C')
    
    sense.clear()
    for i, temp in enumerate(lista_temperature):
        height = int((temp - min_temp) // step) + 1
        for j in range(height):
            if 7 - j >= 0:
                sense.set_pixel(i, 7 - j, (0, 255, 0))

        time.sleep(0.1)

def display_humidity(lista_humidity):
    global current_position
    lista_humidity = lista_humidity[current_position:current_position + 8]

    max_humidity = max(lista_humidity)
    min_humidity = min(lista_humidity)
    humidity_range = max_humidity - min_humidity
    
    if humidity_range <= 8:
        step = 1
    elif humidity_range <= 16:
        step = 2
    else:
        step = 3

    update_max_label(max_humidity_label, f'Najviša vlažnost je {max_humidity} %')
    update_min_label(min_humidity_label, f'Najniža vlažnost je {min_humidity} %')
    
    sense.clear()
    for i, humidity in enumerate(lista_humidity):
        height = int((humidity - min_humidity) // step) + 1
        for j in range(height):
            if 7 - j >= 0:
                sense.set_pixel(i, 7 - j, (0, 0, 255))
        time.sleep(0.1)

def display_pressure(lista_pressure):
    global current_position
    lista_pressure = lista_pressure[current_position:current_position + 8]
    
    max_pressure = max(lista_pressure)
    min_pressure = min(lista_pressure)
    pressure_range = max_pressure - min_pressure
    
    if pressure_range <= 8:
        step = 1
    elif pressure_range <= 16:
        step = 2
    else:
        step = 3

    update_max_label(max_pressure_label, f'Najviši tlak je {max_pressure} hPa')
    update_min_label(min_pressure_label, f'Najniži tlak je {min_pressure} hPa')
    
    sense.clear()
    for i, pressure in enumerate(lista_pressure):
        height = int((pressure - min_pressure) // step) + 1
        for j in range(height):
            if 7 - j >= 0:
                sense.set_pixel(i, 7 - j, (255, 0, 0))
        time.sleep(0.1)
        
def navigate_in_time(event):
    global current_position
    
    if event.action == 'pressed' and event.direction == 'left':
        current_position = max(0, current_position - 1)
    elif event.action == 'pressed' and event.direction == 'right':
        current_position = min(len(lista_temperature) - 8, current_position + 1)
    
    sense.clear()
    if display_mode == 0:
        display_temperature(lista_temperature)
    elif display_mode == 1:
        display_humidity(lista_humidity)
    elif display_mode == 2:
        display_pressure(lista_pressure)

def check_joystick():
    for event in sense.stick.get_events():
        if event.action == 'pressed' and event.direction == 'middle':
            global display_mode
            display_mode = (display_mode + 1) % 3
            sense.clear()

            if display_mode == 0:
                display_temperature(lista_temperature)
            elif display_mode == 1:
                display_humidity(lista_humidity)
            elif display_mode == 2:
                display_pressure(lista_pressure)
        
        navigate_in_time(event)
    
    root.after(100, check_joystick)

# Start the Tkinter main loop and joystick check
root.after(100, check_joystick)
root.mainloop()
