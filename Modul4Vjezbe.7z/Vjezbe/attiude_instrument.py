import time
from sense_emu import SenseHat
sense=SenseHat()

R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
Dg=(40,40,40)
Gr=(190,190,190)
O=(255,128,0)
P=(240,90,120)
X=(40,100,60)
Br=(165,42,42)
Sm = (124,63,0)

def read_sensors():
        
    roll, pitch, yaw  = sense.get_orientation().values()

    roll = round(roll,2)
    pitch = round(pitch,2)
    yaw = round(yaw,2)
    return roll, pitch , yaw
 
def number_of_pixels(sensor_value, sensor_min=0, sensor_max=360):
    step=(sensor_max-sensor_min)//8
    #print(step)
    if sensor_value==0 or sensor_value == 180:
        num_px=8
    elif sensor_value > 0 and sensor_value < 180:
        num_px = 3- sensor_value // step
    elif sensor_value > 180 and sensor_value < 360:
        num_px = 11 - sensor_value // step
    else:
        num_px = 0
            
    
    return int(num_px)
 
 
t,p,h=read_sensors()
 

 
xt,xp,xh=-200,-200,-200
while True:
    sense.clear()
    roll,pitch,yaw =read_sensors()
    mjerenje = f'Roll: {roll}; Pitch {pitch}; Yaw: {yaw}'
    print(mjerenje)
    rpx = number_of_pixels(roll)
    ppx = number_of_pixels(pitch)
    ypx = number_of_pixels(yaw)
    if rpx != 8:
        sense.set_pixel(0,rpx,C)
        sense.set_pixel(1,rpx,C)
    if ppx != 8:
        sense.set_pixel(3,ppx,Sm)
        sense.set_pixel(4,ppx,C)
    if ypx != 8:
        sense.set_pixel(6,ypx,C)
        sense.set_pixel(7,ypx,C)
    time.sleep(0.5)
    time.sleep(0.1)
    
while True:
    
    roll, pitch, yaw  = sense.get_orientation().values()

    roll = round(roll,2)
    pitch = round(pitch,2)
    yaw = round(yaw,2)

    mjerenje = f'Roll: {roll}; Pitch {pitch}; Yaw: {yaw}'
    #sense.show_message(mjerenje)
    print(mjerenje)
    time.sleep(1)
