import tkinter as tk
import sqlite3
import datetime as dt
import time
from sense_db_queries import *
from Sense_db_display import *

sense = SenseHat()
sense.clear()

database_name = 'Meteodata2.db'

def get_timestamp():
    timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return timestamp

location = 'Home'

def create_data_table():
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(create_table_query)
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()

def insert_data(timestamp, loc, temp, humi, pres):
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(insert_data_query, (timestamp, loc, temp, humi, pres))
        sc.commit()
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()

def select_all_data():
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_data_query)
        records = cursor.fetchall()
        print(records)
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()

def select_last_8():
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_data_limit_8_query)
        records = cursor.fetchall()
        print(records)
        data = [[], [], []]  # t(3), h(4), p(5)
        for record in records:
            data[0].append(record[3])
            data[1].append(record[4])
            data[2].append(record[5])
        cursor.close()
    except sqlite3.Error as e:
        data = [[0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0]]
        print(e)
    finally:
        if sc:
            sc.close()
        return data

select_data_last_id = '''SELECT id FROM Meteo ORDER BY id DESC LIMIT 1;'''

select_data_in_range = '''SELECT * FROM Meteo WHERE id>=? AND id<=?'''

def select_data_find_last_id():
    last_id = 1
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_data_last_id)
        records = cursor.fetchone()
        last_id = records[0]
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    finally:
        if sc:
            sc.close()
        return last_id

def select_data_range(id_of_col7):
    try:
        sc = sqlite3.connect(database_name)
        cursor = sc.cursor()
        cursor.execute(select_data_in_range, (id_of_col7 - 7, id_of_col7))
        records = cursor.fetchall()
        print(records)
        data = [[], [], []]  # t(3), h(4), p(5)
        for record in records:
            data[0].append(record[3])
            data[1].append(record[4])
            data[2].append(record[5])
        cursor.close()
    except sqlite3.Error as e:
        data = [[0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0]]
        print(e)
    finally:
        if sc:
            sc.close()
        return data

def read_sensors():
    temperature = round(sense.get_temperature(), 0)
    pressure = round(sense.get_pressure(), 0)
    humidity = round(sense.get_humidity(), 0)
    return temperature, pressure, humidity

create_data_table()

sense.clear()

lista_podataka = select_last_8()
print()
print(lista_podataka)
temperature, humidity, pressure = lista_podataka

data_list = [temperature, humidity, pressure]
data_list_index = 0
data_list_length = len(data_list)
display_data(data_list[data_list_index])

changed = False
live_mode = True
ignore = False
id_of_last_reading = 1
id_of_last_shown = 8
update_display = False
hold_left = False  
hold_right = False  

def update_sensor_data():
    global temperature, humidity, pressure, data_list, id_of_last_shown, id_of_last_reading, update_display, changed
    
    ts = get_timestamp()
    if (int(ts[-2:])) % 5 == 0:
        t, p, h = read_sensors()
        insert_data(ts, location, t, h, p)
        if live_mode:
            temperature, humidity, pressure = select_last_8()
            data_list = [temperature, humidity, pressure]
            id_of_last_shown = id_of_last_reading
        id_of_last_reading = select_data_find_last_id()
        update_display = True

    if not live_mode and changed:
        temperature, humidity, pressure = select_data_range(id_of_last_shown)
        data_list = [temperature, humidity, pressure]
        changed = False

    if update_display:
        display_data(data_list[data_list_index])
        update_display = False

    root.after(1000, update_sensor_data)

def on_button_click(event_type, direction):
    global data_list_index, live_mode, changed, id_of_last_shown, ignore, hold_left, hold_right, update_display
    
    update_display = True
    if event_type == 'pressed':
        if direction == 'middle':
            data_list_index = (data_list_index + 1) % data_list_length
        elif direction == 'left' and id_of_last_shown > 8:
            id_of_last_shown -= 1
            live_mode = False
            changed = True
        elif direction == 'right' and id_of_last_shown < id_of_last_reading:
            id_of_last_shown += 1
            live_mode = False
            changed = True
    elif event_type == 'held':
        if direction == 'left' and id_of_last_shown > 8:
            id_of_last_shown = max(8, id_of_last_shown - 8)
            live_mode = False
            changed = True
        elif direction == 'right' and id_of_last_shown < id_of_last_reading:
            id_of_last_shown = min(id_of_last_reading, id_of_last_shown + 8)
            live_mode = False
            changed = True

    if update_display:
        display_data(data_list[data_list_index])
        update_display = False

root = tk.Tk()
root.title("Sense HAT Control")

button_frame = tk.Frame(root)
button_frame.pack()

buttons = [
    ("Left Press", "pressed", "left"),
    ("Left Hold", "held", "left"),
    ("Middle Press", "pressed", "middle"),
    ("Right Press", "pressed", "right"),
    ("Right Hold", "held", "right")
]

for (text, event_type, direction) in buttons:
    button = tk.Button(button_frame, text=text, command=lambda et=event_type, d=direction: on_button_click(et, d))
    button.pack(side=tk.LEFT)

root.after(1000, update_sensor_data)
root.mainloop()
