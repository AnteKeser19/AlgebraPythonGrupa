import time
from sense_emu import SenseHat
sense=SenseHat()
 
R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
Dg=(40,40,40)
Gr=(190,190,190)
O=(255,128,0)
P=(240,90,120)
X=(40,100,60)
Br=(165,42,42)
Sm=(124, 63, 0)
 
 
 
def read_sensors():
    roll, pitch, yaw = sense.get_orientation().values()
    roll=round(roll,0)
    pitch=round(pitch,0)
    yaw=round(yaw,0)
    return roll,pitch,yaw
 
def number_of_pixels(sensor_value, sensor_min=0, sensor_max=360):
    #step=(sensor_max-sensor_min)//8
    step=22.5
    #print(step)
    blpx=(0,0)
    brpx=(0,0)
 
 
 
 
    if 0<=sensor_value<step/2 or (360-step/2)<sensor_value<360:
        blpx=(0,4)
        brpx=(4,8)
    elif 180-step/2<sensor_value<180+step/2:
        blpx=(4,8)
        brpx=(0,4)
    elif sensor_value==90:
        blpx=(0,8)
        brpx=(0,0)
    elif sensor_value==270:
        blpx=(0,0)
        brpx=(0,8)
    elif sensor_value>0 and sensor_value<step*4:
        hor=4+int(((sensor_value+step)*10))//int((step*10))
        blpx=(0,hor)
        brpx=(hor,8)
 
 
    return (blpx, brpx)
 
 
 
while True:
    sense.clear()
    roll, pitch, yaw=read_sensors()
    mjerenje=f'Roll: {roll}; Pitch: {pitch}; Yaw: {yaw}'
    print(mjerenje)
    blpx,brpx=number_of_pixels(pitch)
    blmin,blmax=blpx
    brmin,brmax=brpx
 
 
    for x in range(8):
        for y in range(blmin,blmax):
            sense.set_pixel(x,y,C)
        for y in range(brmin,brmax):
            sense.set_pixel(x,y,Sm)
 
    time.sleep(0.5)
    time.sleep(0.1)