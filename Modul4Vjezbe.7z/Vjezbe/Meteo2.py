from sense_emu import SenseHat
import time


sense = SenseHat()


R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
Dg=(40,40,40)
Gr=(190,190,190)
O=(255,128,0)
P=(240,90,120)
X=(40,100,60)
Br=(165,42,42)

smiley=[
        K,K,Y,Y,Y,Y,K,K,
        K,Y,Y,Y,Y,Y,Y,K,
        Y,Y,K,Y,Y,K,Y,Y,
        Y,Y,Y,Y,Y,Y,Y,Y,
        Y,Y,K,Y,Y,K,Y,Y,
        Y,Y,Y,K,K,Y,Y,Y,
        K,Y,Y,Y,Y,Y,Y,K,
        K,K,Y,Y,Y,Y,K,K
        ]


sad=[
    K,K,Y,Y,Y,Y,K,K,
    K,Y,Y,Y,Y,Y,Y,K,
    Y,Y,K,Y,Y,K,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,K,K,Y,Y,Y,
    Y,Y,K,Y,Y,K,Y,Y,
    K,Y,Y,Y,Y,Y,Y,K,
    K,K,Y,Y,Y,Y,K,K
    ]


 
flat=[
    K,K,Y,Y,Y,Y,K,K,
    K,Y,Y,Y,Y,Y,Y,K,
    Y,Y,K,Y,Y,K,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,K,K,K,K,Y,Y,
    K,Y,Y,Y,Y,Y,Y,K,
    K,K,Y,Y,Y,Y,K,K
    ]


upozorenje = [
    Y,Y,Y,R,R,Y,Y,Y,
    Y,Y,Y,R,R,Y,Y,Y,
    Y,Y,Y,R,R,Y,Y,Y,
    Y,Y,Y,R,R,Y,Y,Y,
    Y,Y,Y,R,R,Y,Y,Y,
    Y,Y,Y,R,R,Y,Y,Y,
    Y,Y,Y,Y,Y,Y,Y,Y,
    Y,Y,Y,R,R,Y,Y,Y
    ]

while True:
    temperature = sense.get_temperature()
    pressure = sense.get_pressure()
    
    sense.clear()

    if pressure < 1000 or pressure > 1020:
        sense.set_pixels(upozorenje)
    elif temperature < 18:
        sense.set_pixels(flat)
        print("Potrebno grijanje")
    elif temperature > 25:
        sense.set_pixels(sad)
        print("Potrebno hladjenje")
    else:
        sense.set_pixels(smiley)
        print('Bas mi je super')
    
    time.sleep(1)
