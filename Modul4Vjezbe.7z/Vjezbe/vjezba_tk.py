import time
import random
import tkinter as tk
 
 
from sense_emu import SenseHat
sense=SenseHat()
 
sense.clear()
 
R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
 
boje=[R,G,B,W,C,M,Y]
 
x=0 # lijevo
y=0 # gore
tocka_igrac=[x,y]
tocka_racunalo=[random.randint(0,7), random.randint(0,7)]
indeks_boje=0
boja_igrac=boje[indeks_boje]
boja_racunalo=(random.randint(0,255),random.randint(0,255),random.randint(0,255))
 
sense.set_pixel(tocka_igrac[0],tocka_igrac[1],boja_igrac)
sense.set_pixel(tocka_racunalo[0],tocka_racunalo[1],boja_racunalo)
 
def handle_keypress(event):
    print(event.char)
    naredba=event.char
    global tocka_igrac
    global tocka_racunalo
    global boja_igrac
    global boja_racunalo
    x,y=tocka_igrac
    if naredba=='w':
        y-=1
        if y==-1:
            y=0
    elif naredba=='s':
        y+=1
        if y==8:
            y=7
    elif naredba=='a':
        x-=1
        if x==-1:
            x=0
    elif naredba=='d':
        x+=1
        if x==8:
            x=7
    tocka_igrac=[x,y]
    if tocka_igrac==tocka_racunalo:
        print('nasli su se')
        boja_igrac=boja_racunalo
        tocka_racunalo=[random.randint(0,7), random.randint(0,7)]
        boja_racunalo=(random.randint(0,255),random.randint(0,255),random.randint(0,255))
 
    sense.clear()
    sense.set_pixel(tocka_igrac[0],tocka_igrac[1],boja_igrac)
    sense.set_pixel(tocka_racunalo[0],tocka_racunalo[1],boja_racunalo)
 
 
root=tk.Tk()
root.geometry('200x200')
root.bind('<Key>',handle_keypress)
root.mainloop()