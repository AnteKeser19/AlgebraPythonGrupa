create_table_query='''CREATE TABLE IF NOT EXISTS Meteo (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    location TEXT,
                    temperature REAL,
                    humidity REAL,
                    pressure REAL);'''
 
insert_data_query='''INSERT INTO Meteo (timestamp, location, temperature, humidity, pressure)
                    VALUES (?, ?, ?, ?, ?)'''
 
select_data_query='''SELECT * FROM Meteo'''
 
select_data_where_query='''SELECT temperature, humidity, pressure FROM Meteo WHERE ...'''
#nije gotovo
 
select_data_limit_8_query='''	SELECT * FROM 
                                (SELECT * FROM Meteo ORDER BY id DESC LIMIT 8)
                                ORDER BY id ASC;'''