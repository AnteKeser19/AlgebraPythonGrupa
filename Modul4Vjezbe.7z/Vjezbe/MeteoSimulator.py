import time
from sense_emu import SenseHat
sense=SenseHat()

R=(255,0,0)
G=(0,255,0)
B=(0,0,255)
W=(255,255,255)
K=(0,0,0)
C=(0,255,255)
M=(255,0,255)
Y=(255,255,0)
Dg=(40,40,40)
Gr=(190,190,190)
O=(255,128,0)
P=(240,90,120)
X=(40,100,60)
Br=(165,42,42)

 
temperature=round(sense.get_temperature(),1)
#print(temperature)
 
temperature_from_humidity=sense.get_temperature_from_humidity()
temperature_from_pressure=sense.get_temperature_from_pressure()
 
#print(temperature_from_humidity)
#print(temperature_from_pressure)
 
 
pressure=round(sense.get_pressure(),1)
#print(pressure)
 
humidity=round(sense.get_humidity(),1)
#print(humidity)
 
#reading=f'Temp: {temperature}; Press: {pressure}; Hum: {humidity}'
#sense.show_message(reading)
 
def read_sensors():
    temperature=round(sense.get_temperature(),0)
    pressure=round(sense.get_pressure(),0)
    humidity=round(sense.get_humidity(),0)
    return temperature,pressure,humidity
 
def number_of_pixels(sensor_value, sensor_min=0, sensor_max=100):
    step=(sensor_max-sensor_min)/8
    #print(step)
    num_px=((sensor_value-sensor_min+step)*10)//(step*10)
    if num_px==9:
        num_px=8
    #print(int(num_px))
    return int(num_px)
 
 
t,p,h=read_sensors()
 
#print(number_of_pixels(t,-30,105))

tcolor =[B,B,C,G,Y,O,R,R]
pcolor = [Y,Y,Y,Y,Y,G,G,R]
hcolor = [Y,Y,G,G,Gr,Gr,Gr,Gr]
 
xt,xp,xh=-200,-200,-200
while True:
    t,p,h=read_sensors()
    if not((t-2)<xt<(t+2)) or not((p-2)<xp<(p+2)) or not((h-2)<xh<(h+2)):
        sense.clear()
        xt,xp,xh=t,p,h
        print(xt,xp,xh)
        tpx=number_of_pixels(t,-30,105)
        ppx=number_of_pixels(p,260,1260)
        hpx=number_of_pixels(h)                                                    
        for pxrow in range(tpx):
 
            sense.set_pixel(0,7-pxrow,tcolor[tpx-1])
            sense.set_pixel(1,7-pxrow,tcolor[tpx-1])
 
        for pxrow in range(ppx):
 
            sense.set_pixel(3,7-pxrow,pcolor[ppx-1])
            sense.set_pixel(4,7-pxrow,pcolor[ppx-1])     
 
        for pxrow in range(hpx):
 
            sense.set_pixel(6,7-pxrow,hcolor[hpx-1])
            sense.set_pixel(7,7-pxrow,hcolor[hpx-1])
 
 
        time.sleep(0.5)
 
        print('nesto')
    time.sleep(0.1)