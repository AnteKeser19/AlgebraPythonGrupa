from sense_emu import SenseHat
import time
import datetime as dt

sense = SenseHat()
sense.clear()

red = (255,0,0)
orange = (255,135,0)
green = (240,255,0)
better_green = (54,255,0)
light_green = (0,255,61)
light_blue = (0,255,237)
baby_blue = (0,183,255)
blue = (0,0,255)
dark_blue = (17,10,77)
black = (0,0,0)
white = (255,255,255)
flag = True

def display_temperature(temperature):
    sense.clear()
    global flag
    if flag: 
        sense.show_letter("T",
                          text_colour = red,
                          back_colour = black)
        flag = False
    time.sleep(0.5)
    sense.clear()
    
    for i,temp in enumerate(temperature):
        height = max(1,int(temp//5))
        
        if temp < 5:
            color = blue
        elif temp < 10:
            color = light_blue
        elif temp < 15:
            color = light_green
        elif temp < 25:
            color = better_green
        elif temp < 30:
            color = green
        elif temp < 35:
            color = orange
        else:
            color = red
            
        for j in range(height):
            if 7 - j >= 0:
                sense.set_pixel(i,7-j,color)
                
def display_humidity(humidity):
    sense.clear()
    sense.show_letter("H",
                      text_colour = green,
                      back_colour = black)
    time.sleep(0.5)
    sense.clear()
    
    for i, hum in enumerate(humidity):
        height = max(1, int(hum / 10))
        
        if hum < 20:
            color = blue
        elif hum < 25:
            color = light_blue
        elif hum < 30:
            color = baby_blue
        elif hum < 45:
            color = light_green
        elif hum < 60:
            color = green
        elif hum < 70:
            color = orange
        else:
            color = red
            
        for j in range(height):
            if 7 - j >= 0:
                sense.set_pixel(i, 7 - j, color)

def display_pressure(pressure):
    sense.clear()
    sense.show_letter("P",
                      text_colour = baby_blue,
                      back_colour = white)
    time.sleep(0.5)
    sense.clear()
    
    for i, pres in enumerate(pressure):
        if pres < 960:
            height = 1
        elif pres > 1060:
            height = 7
        else:
            height = int((pres - 960) / 20) + 1
        
        if pres < 960:
            color = blue
        elif pres < 980:
            color = baby_blue
        elif pres < 1000:
            color = light_blue
        elif pres < 1010:
            color = light_green
        elif pres < 1020:
            color = better_green
        elif pres < 1035:
            color = orange
        else:
            color = red
        
        for j in range(height):
            if 7 - j >= 0:
                sense.set_pixel(i, 7 - j, color)
            
temperature = []
humidity = []
pressure = []

def get_temperature():
    temp = sense.get_temperature()
    if temp < 0:
            temp = 0
    elif temp > 40:
            temp = 40
    temperature.append(temp)
    if len(temperature) > 8:
        temperature.pop(0)
    display_temperature(temperature)
    
def get_humidity():
    hum = sense.get_humidity()
    humidity.append(hum)
    if len(humidity) > 8:
        humidity.pop(0)
    display_humidity(humidity)

def get_pressure():
    pres = sense.get_pressure()
    pressure.append(pres)
    if len(pressure) > 8:
        pressure.pop(0)
    display_pressure(pressure)
    
def main():
    global flag
    interval = dt.timedelta(seconds=5)
    next_time = dt.datetime.now() + interval
    display_mode = 0
    while True:
        current_time = dt.datetime.now()
        if current_time >= next_time:
            if display_mode == 0:
                get_temperature()
            elif display_mode == 1:
                get_humidity()
            elif display_mode == 2:
                get_pressure()
                
            for event in sense.stick.get_events():
                if event.action == 'pressed' and event.direction == 'middle':
                    display_mode = (display_mode +1) % 3
                    sense.clear()
                    flag = True
                    time.sleep(0.5)
            next_time = current_time + interval

main()


